import shapes.Circle;
import shapes.Square;
import shapes.Rectangle;

public class calculate {
    public static void main(String[] args) {

        Circle c = new Circle(5);
        Square s = new Square(4);
        Rectangle r = new Rectangle(6, 3);

        System.out.println("Circle:");
        System.out.println("Area = " + c.area());
        System.out.println("Perimeter = " + c.perimeter());

        System.out.println("\nSquare:");
        System.out.println("Area = " + s.area());
        System.out.println("Perimeter = " + s.perimeter());

        System.out.println("\nRectangle:");
        System.out.println("Area = " + r.area());
        System.out.println("Perimeter = " + r.perimeter());
    }
}
