
package tools;

public class Filter {
    public void applyFilter() {
        System.out.println("Photo Filter Applied Successfully!");
        System.out.println("Filter Name: Black and White");
    }
}
