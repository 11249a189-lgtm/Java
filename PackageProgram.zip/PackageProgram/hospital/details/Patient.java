
package hospital.details;

public class Patient {
    public void display() {
        System.out.println("Hospital Patient Details");
        System.out.println("Patient Name: Arun");
        System.out.println("Patient Age: 25");
        System.out.println("Disease: Fever");
    }
}
