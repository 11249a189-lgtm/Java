
import hospital.details.Patient;

public class Hospital {
    public static void main(String[] args) {

        Patient p = new Patient();

        p.display();
    }
}
