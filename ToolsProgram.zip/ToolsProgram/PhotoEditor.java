
import tools.Filter;

public class PhotoEditor {
    public static void main(String[] args) {

        Filter f = new Filter();

        f.applyFilter();
    }
}
