
import java.util.Scanner;

public class KeywordSearch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a message: ");
        String msg = sc.nextLine();

        System.out.print("Enter keyword: ");
        String key = sc.nextLine();

        if (msg.contains(key)) {
            System.out.println("Keyword found");
        } else {
            System.out.println("Keyword not found");
        }

        sc.close();
    }
}
