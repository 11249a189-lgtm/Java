
import java.util.Scanner;

public class ShoppingDiscount {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter purchase amount: ");
        double amount = sc.nextDouble();

        if (amount > 1000) {
            amount = amount - (amount * 0.10);
            System.out.println("10% Discount Applied");
        } else {
            System.out.println("No Discount");
        }

        System.out.println("Final Amount: Rs. " + amount);

        sc.close();
    }
}
