
import java.util.Scanner;

public class CompareNames {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Employee 1 Name: ");
        String emp1 = sc.nextLine();

        System.out.print("Enter Employee 2 Name: ");
        String emp2 = sc.nextLine();

        if (emp1.equalsIgnoreCase(emp2)) {
            System.out.println("Both names are same");
        } else {
            System.out.println("Both names are different");
        }

        sc.close();
    }
}
