
interface Notification {
    void send();
}

class Email implements Notification {
    public void send() {
        System.out.println("Email sent: Your order has been shipped");
    }
}

class SMS implements Notification {
    public void send() {
        System.out.println("SMS sent: Your order has been shipped");
    }
}

public class NotificationDemo {
    public static void main(String[] args) {
        Notification n;

        n = new Email();
        n.send();

        n = new SMS();
        n.send();
    }
}
