
class Employee {
    String name = "Anil";
    double salary = 50000.0;
}

class Manager extends Employee {
    double bonus = 10000.0;

    void display() {
        System.out.println("Name: " + name);
        System.out.println("Salary: Rs. " + salary);
        System.out.println("Bonus: Rs. " + bonus);
        System.out.println("Total Pay: Rs. " + (salary + bonus));
    }
}

public class ManagerDemo {
    public static void main(String[] args) {
        Manager m = new Manager();
        m.display();
    }
}
