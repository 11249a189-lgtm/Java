
interface Fare {
    void calculateFare();
}

class Bus implements Fare {
    public void calculateFare() {
        System.out.println("Bus Fare: Rs. 20");
    }
}

class Auto implements Fare {
    public void calculateFare() {
        System.out.println("Auto Fare: Rs. 50");
    }
}

public class FareDemo {
    public static void main(String[] args) {

        Bus b = new Bus();
        Auto a = new Auto();

        b.calculateFare();
        a.calculateFare();
    }
}
