
import java.util.Scanner;

public class HighestMark {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] marks = new int[5];

        System.out.println("Enter 5 marks in a single line:");

        for (int i = 0; i < 5; i++) {
            marks[i] = sc.nextInt();
        }

        int highest = marks[0];

        for (int i = 1; i < 5; i++) {
            if (marks[i] > highest) {
                highest = marks[i];
            }
        }

        System.out.println("Highest Mark: " + highest);

        sc.close();
    }
}
