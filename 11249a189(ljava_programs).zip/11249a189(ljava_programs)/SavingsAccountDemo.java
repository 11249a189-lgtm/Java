
class Account {
    double balance = 5000.0;
}

class SavingsAccount extends Account {
    void display() {
        System.out.println("Savings Account Details:");
        System.out.println("Account Balance: Rs. " + balance);
    }
}

public class SavingsAccountDemo {
    public static void main(String[] args) {
        SavingsAccount s = new SavingsAccount();
        s.display();
    }
}
